/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import { 
  Refrigerator, 
  ChefHat, 
  Utensils, 
  Sparkles, 
  Loader2, 
  Plus, 
  X,
  Flame,
  Clock,
  ArrowRight,
  Home,
  Heart,
  Settings as SettingsIcon,
  ChevronLeft,
  Trash2,
  Share2
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

// Utility for Tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Initialize Gemini
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const MEAL_TYPES = ["Café da Manhã", "Almoço", "Jantar", "Lanche", "Sobremesa"];
const CREATIVITY_LEVELS = [
  { id: "normal", label: "Tradicional", icon: Utensils, desc: "Receitas clássicas e seguras." },
  { id: "creative", label: "Criativo", icon: Sparkles, desc: "Combinações interessantes." },
  { id: "wild", label: "Ousado", icon: Flame, desc: "Fusões inesperadas." },
];

const QUICK_INGREDIENTS = ["Ovo", "Leite", "Arroz", "Feijão", "Frango", "Cebola", "Alho", "Batata", "Tomate", "Queijo"];

interface SavedRecipe {
  id: string;
  title: string;
  content: string;
  date: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "favorites" | "settings">("home");
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [mealType, setMealType] = useState(MEAL_TYPES[1]);
  const [creativity, setCreativity] = useState("creative");
  const [recipe, setRecipe] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<SavedRecipe[]>([]);
  const [viewingFavorite, setViewingFavorite] = useState<SavedRecipe | null>(null);
  
  const recipeRef = useRef<HTMLDivElement>(null);

  // Load favorites from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("temnageladeira_favs");
    if (saved) setFavorites(JSON.parse(saved));
  }, []);

  // Save favorites to localStorage
  useEffect(() => {
    localStorage.setItem("temnageladeira_favs", JSON.stringify(favorites));
  }, [favorites]);

  const addIngredient = (val: string, e?: React.FormEvent) => {
    e?.preventDefault();
    const trimmed = val.trim().toLowerCase();
    if (trimmed && !ingredients.includes(trimmed)) {
      setIngredients([...ingredients, trimmed]);
      setInputValue("");
    }
  };

  const removeIngredient = (ing: string) => {
    setIngredients(ingredients.filter((i) => i !== ing));
  };

  const generateRecipe = async () => {
    if (ingredients.length === 0) {
      setError("Adicione pelo menos um ingrediente.");
      return;
    }

    setLoading(true);
    setError(null);
    setRecipe(null);

    try {
      const creativityPrompt = 
        creativity === "wild" ? "seja extremamente ousado e experimental" :
        creativity === "creative" ? "seja criativo e sugira combinações interessantes" :
        "seja tradicional e prático";

      const prompt = `
        Você é um Chef de Cozinha IA criativo chamado TemNaGeladeira.
        Crie uma receita de ${mealType} usando os seguintes ingredientes: ${ingredients.join(", ")}.
        Nível de criatividade: ${creativityPrompt}.
        
        A receita deve ser RESUMIDA, DIRETA e BEM ORGANIZADA para uma leitura rápida em dispositivos móveis.
        
        A receita deve incluir:
        1. Um nome criativo e apetitoso (use # para o título).
        2. Tempo de preparo e porções (em uma única linha).
        3. Lista de ingredientes (use tópicos).
        4. Modo de preparo (passos curtos e numerados).
        5. Uma "Dica do Chef" (uma única frase curta).

        Use Markdown. Responda em Português do Brasil.
      `;

      const response = await genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });

      setRecipe(response.text);
      
      setTimeout(() => {
        recipeRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } catch (err) {
      console.error(err);
      setError("Erro ao gerar receita. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const saveToFavorites = () => {
    if (!recipe) return;
    const lines = recipe.split('\n');
    const title = lines[0].replace(/^[#\s*]+/, '').trim() || "Receita Sem Título";
    
    // Check if already in favorites
    if (favorites.some(f => f.title === title)) {
      alert("Esta receita já está nos seus favoritos!");
      return;
    }

    const newFav: SavedRecipe = {
      id: Date.now().toString(),
      title,
      content: recipe,
      date: new Date().toLocaleDateString()
    };
    setFavorites([newFav, ...favorites]);
    alert("Receita salva nos favoritos!");
  };

  const removeFavorite = (id: string) => {
    setFavorites(favorites.filter(f => f.id !== id));
    if (viewingFavorite?.id === id) setViewingFavorite(null);
  };

  const getRecipeTitle = (text: string | null) => {
    if (!text) return "";
    return text.split('\n')[0].replace(/^[#\s*]+/, '').trim();
  };

  const renderHome = () => (
    <div className="space-y-8 pb-24">
      {/* Hero Section */}
      <section className="text-center space-y-2 pt-4">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            O que <span className="text-orange-500">tem na geladeira</span>?
          </h2>
          <p className="text-slate-500 text-sm">
            Gere receitas únicas com o que você tem em casa.
          </p>
        </motion.div>
      </section>

      {/* Input Section */}
      <section className="bg-white rounded-3xl shadow-sm border border-slate-100 p-6 space-y-6">
        <div className="space-y-4">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
            <Utensils className="w-3 h-3" />
            Ingredientes
          </label>
          <form onSubmit={(e) => addIngredient(inputValue, e)} className="relative">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Frango, Tomate..."
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3.5 pr-14 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-base placeholder:text-slate-400"
            />
            <button
              type="submit"
              className="absolute right-1.5 top-1.5 bottom-1.5 bg-orange-500 text-white px-3.5 rounded-xl shadow-sm hover:bg-orange-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </form>

          <div className="space-y-2">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">Sugestões:</p>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_INGREDIENTS.map((item) => (
                <button
                  key={item}
                  onClick={() => addIngredient(item)}
                  disabled={ingredients.includes(item.toLowerCase())}
                  className="text-[11px] bg-slate-50 hover:bg-slate-100 disabled:opacity-30 text-slate-600 px-2.5 py-1 rounded-lg border border-slate-200 transition-all duration-200"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap gap-2 min-h-[32px]">
            <AnimatePresence>
              {ingredients.map((ing) => (
                <motion.span
                  key={ing}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="bg-orange-50 text-orange-700 px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 border border-orange-100"
                >
                  {ing}
                  <button onClick={() => removeIngredient(ing)} className="hover:text-orange-900"><X className="w-3 h-3" /></button>
                </motion.span>
              ))}
            </AnimatePresence>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Refeição</label>
            <div className="flex overflow-x-auto gap-2 pb-2 no-scrollbar">
              {MEAL_TYPES.map((type) => (
                <button
                  key={type}
                  onClick={() => setMealType(type)}
                  className={cn(
                    "whitespace-nowrap px-4 py-2 rounded-xl text-xs font-medium border transition-all",
                    mealType === type 
                      ? "bg-orange-500 border-orange-500 text-white" 
                      : "bg-white border-slate-200 text-slate-600 hover:border-orange-300"
                  )}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400">Criatividade</label>
            <div className="grid grid-cols-3 gap-2">
              {CREATIVITY_LEVELS.map((level) => (
                <button
                  key={level.id}
                  onClick={() => setCreativity(level.id)}
                  className={cn(
                    "flex flex-col items-center gap-1 p-2 rounded-xl border transition-all",
                    creativity === level.id 
                      ? "bg-orange-50 border-orange-500 text-orange-600" 
                      : "bg-white border-slate-200 text-slate-500 hover:border-orange-300"
                  )}
                >
                  <level.icon className="w-4 h-4" />
                  <span className="text-[10px] font-bold">{level.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <button
          onClick={generateRecipe}
          disabled={loading || ingredients.length === 0}
          className={cn(
            "w-full py-4 rounded-2xl font-bold text-base flex items-center justify-center gap-2 transition-all",
            loading || ingredients.length === 0 
              ? "bg-slate-100 text-slate-400" 
              : "bg-orange-500 text-white shadow-lg shadow-orange-200 hover:bg-orange-600"
          )}
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChefHat className="w-5 h-5" />}
          {loading ? "Cozinhando..." : "Gerar Receita"}
        </button>
        {error && <p className="text-red-500 text-xs text-center font-medium">{error}</p>}
      </section>

      {/* Recipe Result */}
      <AnimatePresence>
        {recipe && (
          <motion.section
            ref={recipeRef}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-sm border border-orange-100 overflow-hidden"
          >
            <div className="bg-orange-500 px-6 py-4 flex items-center justify-between text-white">
              <div className="flex items-center gap-2 overflow-hidden">
                <ChefHat className="w-5 h-5 flex-shrink-0" />
                <span className="font-bold text-xs uppercase truncate">
                  {getRecipeTitle(recipe)}
                </span>
              </div>
              <button onClick={saveToFavorites} className="p-2 hover:bg-white/20 rounded-lg transition-colors flex-shrink-0">
                <Heart className={cn("w-5 h-5", favorites.some(f => f.title === getRecipeTitle(recipe)) ? "fill-white" : "")} />
              </button>
            </div>
            <div className="p-6 prose prose-sm prose-slate max-w-none prose-orange">
              <ReactMarkdown>{recipe}</ReactMarkdown>
            </div>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );

  const renderFavorites = () => (
    <div className="space-y-6 pb-24 pt-4">
      <h2 className="text-2xl font-bold text-slate-900 px-2">Receitas Favoritas</h2>
      
      {viewingFavorite ? (
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm">
          <div className="bg-orange-500 px-6 py-4 flex items-center justify-between text-white">
            <div className="flex items-center gap-2 overflow-hidden">
              <ChefHat className="w-5 h-5 flex-shrink-0" />
              <span className="font-bold text-xs uppercase truncate">
                {viewingFavorite.title}
              </span>
            </div>
            <button onClick={() => removeFavorite(viewingFavorite.id)} className="p-2 hover:bg-white/20 rounded-lg transition-colors flex-shrink-0">
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
          
          <div className="p-4 border-b border-slate-100 flex items-center bg-white sticky top-0 z-10 text-orange-500">
            <button onClick={() => setViewingFavorite(null)} className="flex items-center gap-1 font-bold text-sm">
              <ChevronLeft className="w-4 h-4" /> Voltar para a lista
            </button>
          </div>

          <div className="p-6 prose prose-sm prose-slate max-w-none prose-orange">
            <ReactMarkdown>
              {viewingFavorite.content.split('\n').slice(1).join('\n')}
            </ReactMarkdown>
          </div>
        </motion.div>
      ) : (
        <div className="grid gap-4">
          {favorites.length === 0 ? (
            <div className="text-center py-20 space-y-4">
              <div className="bg-slate-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                <Heart className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-slate-400 text-sm font-medium">Você ainda não salvou nenhuma receita.</p>
            </div>
          ) : (
            favorites.map((fav) => (
              <motion.div
                key={fav.id}
                layoutId={fav.id}
                className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer hover:border-orange-200 transition-colors"
                onClick={() => setViewingFavorite(fav)}
              >
                <div className="flex-1 pr-4">
                  <h3 className="font-black text-slate-900 text-base leading-snug mb-1">
                    {fav.title}
                  </h3>
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-orange-500 bg-orange-50 px-1.5 py-0.5 rounded">Receita</span>
                    <p className="text-[10px] text-slate-400 font-medium">{fav.date}</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-orange-500 transition-colors" />
              </motion.div>
            ))
          )}
        </div>
      )}
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6 pb-24 pt-4">
      <h2 className="text-2xl font-bold text-slate-900 px-2">Configurações</h2>
      <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden divide-y divide-slate-50">
        <div className="p-4 flex items-center justify-between">
          <div className="text-left">
            <p className="font-bold text-slate-800 text-sm">Notificações</p>
            <p className="text-[10px] text-slate-400">Receba dicas de culinária</p>
          </div>
          <div className="w-10 h-5 bg-orange-500 rounded-full relative">
            <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-sm" />
          </div>
        </div>
        <div className="p-4 flex items-center justify-between text-left">
          <div className="flex-1">
            <p className="font-bold text-slate-800 text-sm">Idioma</p>
            <p className="text-[10px] text-slate-400">Português (Brasil)</p>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-300" />
        </div>
        <button 
          onClick={() => {
            if (confirm("Tem certeza que deseja apagar todas as receitas salvas?")) {
              setFavorites([]);
              alert("Dados limpos com sucesso.");
            }
          }}
          className="w-full p-4 flex items-center justify-between transition-colors hover:bg-slate-50"
        >
          <p className="font-bold text-red-500 text-sm">Limpar todos os dados</p>
          <Trash2 className="w-4 h-4 text-red-300" />
        </button>
      </div>
      
      <div className="p-6 text-center space-y-2">
        <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest leading-loose">TemNaGeladeira? v1.0.0</p>
        <div className="flex justify-center gap-4">
          <Share2 className="w-4 h-4 text-slate-300" />
          <Sparkles className="w-4 h-4 text-slate-300" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#FDFDFD] text-slate-900 font-sans selection:bg-orange-100 transition-colors duration-300">
      {/* Mobile Header */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100 px-6 py-4 flex items-center justify-between transition-colors">
        <div className="flex items-center gap-2">
          <div className="bg-orange-500 p-1.5 rounded-lg shadow-sm">
            <Refrigerator className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-black tracking-tight text-slate-800">
            TemNa<span className="text-orange-500">Geladeira?</span>
          </h1>
        </div>
        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center transition-colors">
          <ChefHat className="w-4 h-4 text-slate-400" />
        </div>
      </header>

      <main className="max-w-md mx-auto px-5 pt-4">
        {activeTab === "home" && renderHome()}
        {activeTab === "favorites" && renderFavorites()}
        {activeTab === "settings" && renderSettings()}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-slate-100 px-8 py-4 z-50 transition-colors">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <button 
            onClick={() => setActiveTab("home")}
            className={cn(
              "flex flex-col items-center gap-1 transition-all",
              activeTab === "home" ? "text-orange-500 scale-110" : "text-slate-300"
            )}
          >
            <Home className={cn("w-6 h-6", activeTab === "home" ? "fill-orange-500/10" : "")} />
            <span className="text-[10px] font-bold">Home</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("favorites")}
            className={cn(
              "flex flex-col items-center gap-1 transition-all",
              activeTab === "favorites" ? "text-orange-500 scale-110" : "text-slate-300"
            )}
          >
            <Heart className={cn("w-6 h-6", activeTab === "favorites" ? "fill-orange-500/10" : "")} />
            <span className="text-[10px] font-bold">Favoritos</span>
          </button>
          
          <button 
            onClick={() => setActiveTab("settings")}
            className={cn(
              "flex flex-col items-center gap-1 transition-all",
              activeTab === "settings" ? "text-orange-500 scale-110" : "text-slate-300"
            )}
          >
            <SettingsIcon className={cn("w-6 h-6", activeTab === "settings" ? "fill-orange-500/10" : "")} />
            <span className="text-[10px] font-bold">Ajustes</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
